﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MANSMS_1_
{
    public partial class frm_loading : Form
    {
        public frm_loading()
        {
            InitializeComponent();
        }

        private void frm_loading_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (pb_loading.Value != 100)
            {
                pb_loading.Increment(10);
                lbl_loading.Text = pb_loading.Value.ToString() + "%";
            }
            else
            {
                timer1.Stop();
                this.Hide();
                frm_adminmain vfrmadminmain = new frm_adminmain();
                vfrmadminmain.Show();
            }
        }

        private void seclvl_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pb_loading_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lbl_loading_Click(object sender, EventArgs e)
        {

        }
    }
}
