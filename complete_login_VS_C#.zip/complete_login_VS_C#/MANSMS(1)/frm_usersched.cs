﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MANSMS_1_
{
    public partial class frm_usersched : Form
    {
        public frm_usersched()
        {
            InitializeComponent();
        }

        private void frm_usersched_Load(object sender, EventArgs e)
        {

        }

        private void adminProfileToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_adminprofile vfrmadminprofile = new frm_adminprofile();
            vfrmadminprofile.Show();
        }

        private void viewUsersAccountToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_useracc vfrmuseracc = new frm_useracc();
            vfrmuseracc.Show();
        }

        private void loginHistoryToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_userloginhis vfrmuserloginhis = new frm_userloginhis();
            vfrmuserloginhis.Show();
        }

        private void studentsprofileToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_stdprof vfrmstdprof = new frm_stdprof();
            vfrmstdprof.Show();
        }

        private void addNewStudentsProfileToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_addstdprof vfrmaddstdprof = new frm_addstdprof();
            vfrmaddstdprof.Show();
        }

        private void activityLogToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_stdactlog vfrmstdacclog = new frm_stdactlog();
            vfrmstdacclog.Show();
        }

        private void accountSettingsToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_accsett vfrmaccsett = new frm_accsett();
            vfrmaccsett.Show();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder qry = new StringBuilder();
            qry.AppendLine("INSERT INTO UserLogs ");
            qry.AppendLine("(");
            qry.AppendLine("UserId,");
            qry.AppendLine("Activity,");
            qry.AppendLine("LogDate,");
            qry.AppendLine("Remarks");
            qry.AppendLine(") VALUES (");
            qry.AppendLine("'" + GlobalVariable.LoggedInUser.Rows[0].Field<int>("ID").ToString() + "',");
            qry.AppendLine("'" + Enums.Activity.LOGOUT.ToString() + "',");
            qry.AppendLine("'" + DateTime.Now.ToString("MMM-dd-yyyy hh:mm:ss tt") + "',");
            qry.AppendLine("'" + "" + "'");
            qry.AppendLine(")");
            DataAccessLayer.ExecuteNonQuery(qry.ToString());

            this.Close();

            Program.FRM_LOGIN.Show();
        }
    }
}
