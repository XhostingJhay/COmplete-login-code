﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MANSMS_1_
{
    public partial class frm_usermain : Form
    {
        public frm_usermain()
        {
            InitializeComponent();
        }

        private void lbl_date_Click(object sender, EventArgs e)
        {

        }

        private void lbl_time_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
          
        }

        private void userProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void userScheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void studentsprofileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addNewStudentsProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void activityLogToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void accountSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
