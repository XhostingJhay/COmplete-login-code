﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MANSMS_1_
{
    public partial class frm_signup : Form
    {
        public frm_signup()
        {
            InitializeComponent();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_login vfrmlogin = new frm_login();
            vfrmlogin.Show();
        }

        private void btn_createaccount_Click(object sender, EventArgs e)
        {
            if (txt_retypepassword.Text == txt_password.Text)
            {
                if (txt_fname.Text == String.Empty || txt_lname.Text == String.Empty || txt_password.Text == String.Empty || txt_username.Text == String.Empty)
                {
                    MessageBox.Show("Please Enter Data!", "Message");
                }
                else
                {

                    var existingUser = DataAccessLayer.GetRecords("SELECT * FROM UserAccount where username = '" + txt_username.Text + "'");
                    if (existingUser.Rows.Count > 0)
                    {
                        MessageBox.Show("Username Already Exist!", "Message");
                        return;
                    }


                    StringBuilder qry = new StringBuilder();
                    qry.AppendLine("INSERT INTO UserAccount ");
                    qry.AppendLine("(");
                    qry.AppendLine("username,");
                    qry.AppendLine("[password],");
                    qry.AppendLine("fname,");
                    qry.AppendLine("mi,");
                    qry.AppendLine("lname");
                    qry.AppendLine(") VALUES (");
                    qry.AppendLine("'" + txt_username.Text.Trim() + "',");
                    qry.AppendLine("'" + txt_password.Text.Trim() + "',");
                    qry.AppendLine("'" + txt_fname.Text.Trim() + "',");
                    qry.AppendLine("'" + txt_mi.Text.Trim() + "',");
                    qry.AppendLine("'" + txt_lname.Text.Trim() + "'");
                    qry.AppendLine(")");

                    DataAccessLayer.ExecuteNonQuery(qry.ToString());

                    MessageBox.Show("Account Successfully Created!", "Message");
                    this.Close();

                }
            }
        }

        private void frm_signup_Load(object sender, EventArgs e)
        {

        }
    }
}
