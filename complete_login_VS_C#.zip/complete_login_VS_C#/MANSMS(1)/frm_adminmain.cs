﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MANSMS_1_
{
    public partial class frm_adminmain : Form
    {
        public frm_adminmain()
        {
            InitializeComponent();
        }

        private void lbl_adminname_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void frm_adminmain_Load(object sender, EventArgs e)
        {
            var loggedInUser = GlobalVariable.LoggedInUser;

           lbl_adminname.Text =  loggedInUser.Rows[0].Field<string>("username");

            lbl_date.Text = DateTime.Now.ToString("MMM-dd-yyyy");
            lbl_time.Text = DateTime.Now.ToString("hh:mm tt");

        }
        private void lbl_time_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lbl_date_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void adminProfileToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_adminprofile vfrmadminprofile = new frm_adminprofile();
            vfrmadminprofile.Show();
        }

        private void viewUsersAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_useracc vfrmuseracc = new frm_useracc();
            vfrmuseracc.Show();
        }

        private void loginHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_userloginhis vfrmuserloginhis = new frm_userloginhis();
            vfrmuserloginhis.Show();
        }

        private void scheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_usersched vfrmusersched = new frm_usersched();
            vfrmusersched.Show();
        }

        private void studentsprofileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_stdprof vfrmstdprof = new frm_stdprof();
            vfrmstdprof.Show();
        }
        private void addNewStudentsProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_addstdprof vfrmaddstdprof = new frm_addstdprof();
            vfrmaddstdprof.Show();
        }

        private void activityLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_stdactlog vfrmstdacclog = new frm_stdactlog();
            vfrmstdacclog.Show();
        }

        private void accountSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_accsett vfrmaccsett = new frm_accsett();
            vfrmaccsett.Show();
        }

        private void frm_adminmain_FormClosing(object sender, FormClosingEventArgs e)
        {
          
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {

            StringBuilder qry = new StringBuilder();
            qry.AppendLine("INSERT INTO UserLogs ");
            qry.AppendLine("(");
            qry.AppendLine("UserId,");
            qry.AppendLine("Activity,");
            qry.AppendLine("LogDate,");
            qry.AppendLine("Remarks");
            qry.AppendLine(") VALUES (");
            qry.AppendLine("'" + GlobalVariable.LoggedInUser.Rows[0].Field<int>("ID").ToString() + "',");
            qry.AppendLine("'" + Enums.Activity.LOGOUT.ToString() + "',");
            qry.AppendLine("'" + DateTime.Now.ToString("MMM-dd-yyyy hh:mm:ss tt") + "',");
            qry.AppendLine("'" + "" + "'");
            qry.AppendLine(")");
            DataAccessLayer.ExecuteNonQuery(qry.ToString());

            this.Close();

            Program.FRM_LOGIN.Show();

        }

        private void manageUsersAccountsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        //internal void show()
        //{
        //    throw new NotImplementedException();
        //}
        
    }
}
