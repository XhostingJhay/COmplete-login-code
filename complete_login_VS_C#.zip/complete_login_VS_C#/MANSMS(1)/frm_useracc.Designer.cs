﻿namespace MANSMS_1_
{
    partial class frm_useracc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminProfileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.manageUsersAccountsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentsprofileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewStudentsProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activityLogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbl_adminname = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dtgrid_useracc = new System.Windows.Forms.DataGridView();
            this._MANSMS_DATABASEDataSet = new MANSMS_1_._MANSMS_DATABASEDataSet();
            this.mANSMSDATABASEDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.grpbx_filter = new System.Windows.Forms.GroupBox();
            this.cb_seclvl = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_gender = new System.Windows.Forms.ComboBox();
            this.lbl_gender = new System.Windows.Forms.Label();
            this.grpbx_search = new System.Windows.Forms.GroupBox();
            this.txt_fname = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrid_useracc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._MANSMS_DATABASEDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mANSMSDATABASEDataSetBindingSource)).BeginInit();
            this.grpbx_filter.SuspendLayout();
            this.grpbx_search.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminToolStripMenuItem,
            this.menuToolStripMenuItem,
            this.settingsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1394, 37);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.adminToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminProfileToolStripMenuItem1,
            this.manageUsersAccountsToolStripMenuItem});
            this.adminToolStripMenuItem.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(169, 33);
            this.adminToolStripMenuItem.Text = "Administrator";
            // 
            // adminProfileToolStripMenuItem1
            // 
            this.adminProfileToolStripMenuItem1.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminProfileToolStripMenuItem1.Name = "adminProfileToolStripMenuItem1";
            this.adminProfileToolStripMenuItem1.Size = new System.Drawing.Size(337, 34);
            this.adminProfileToolStripMenuItem1.Text = "Profile";
            this.adminProfileToolStripMenuItem1.Click += new System.EventHandler(this.adminProfileToolStripMenuItem1_Click_1);
            // 
            // manageUsersAccountsToolStripMenuItem
            // 
            this.manageUsersAccountsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loginHistoryToolStripMenuItem,
            this.scheduleToolStripMenuItem});
            this.manageUsersAccountsToolStripMenuItem.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manageUsersAccountsToolStripMenuItem.Name = "manageUsersAccountsToolStripMenuItem";
            this.manageUsersAccountsToolStripMenuItem.Size = new System.Drawing.Size(337, 34);
            this.manageUsersAccountsToolStripMenuItem.Text = "Manage User\'s Accounts";
            // 
            // loginHistoryToolStripMenuItem
            // 
            this.loginHistoryToolStripMenuItem.Name = "loginHistoryToolStripMenuItem";
            this.loginHistoryToolStripMenuItem.Size = new System.Drawing.Size(229, 34);
            this.loginHistoryToolStripMenuItem.Text = "Log-in History";
            this.loginHistoryToolStripMenuItem.Click += new System.EventHandler(this.loginHistoryToolStripMenuItem_Click_1);
            // 
            // scheduleToolStripMenuItem
            // 
            this.scheduleToolStripMenuItem.Name = "scheduleToolStripMenuItem";
            this.scheduleToolStripMenuItem.Size = new System.Drawing.Size(229, 34);
            this.scheduleToolStripMenuItem.Text = "Schedule";
            this.scheduleToolStripMenuItem.Click += new System.EventHandler(this.scheduleToolStripMenuItem_Click_1);
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentsprofileToolStripMenuItem,
            this.activityLogToolStripMenuItem});
            this.menuToolStripMenuItem.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(273, 33);
            this.menuToolStripMenuItem.Text = "Manage User\'s Students";
            this.menuToolStripMenuItem.Click += new System.EventHandler(this.menuToolStripMenuItem_Click);
            // 
            // studentsprofileToolStripMenuItem
            // 
            this.studentsprofileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewStudentsProfileToolStripMenuItem});
            this.studentsprofileToolStripMenuItem.Name = "studentsprofileToolStripMenuItem";
            this.studentsprofileToolStripMenuItem.Size = new System.Drawing.Size(209, 34);
            this.studentsprofileToolStripMenuItem.Text = "Profile";
            this.studentsprofileToolStripMenuItem.Click += new System.EventHandler(this.studentsprofileToolStripMenuItem_Click_1);
            // 
            // addNewStudentsProfileToolStripMenuItem
            // 
            this.addNewStudentsProfileToolStripMenuItem.Name = "addNewStudentsProfileToolStripMenuItem";
            this.addNewStudentsProfileToolStripMenuItem.Size = new System.Drawing.Size(354, 34);
            this.addNewStudentsProfileToolStripMenuItem.Text = "Add New Student\'s Profile";
            this.addNewStudentsProfileToolStripMenuItem.Click += new System.EventHandler(this.addNewStudentsProfileToolStripMenuItem_Click_1);
            // 
            // activityLogToolStripMenuItem
            // 
            this.activityLogToolStripMenuItem.Name = "activityLogToolStripMenuItem";
            this.activityLogToolStripMenuItem.Size = new System.Drawing.Size(209, 34);
            this.activityLogToolStripMenuItem.Text = "Activity Log";
            this.activityLogToolStripMenuItem.Click += new System.EventHandler(this.activityLogToolStripMenuItem_Click_1);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.accountSettingsToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.settingsToolStripMenuItem.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(110, 33);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // accountSettingsToolStripMenuItem
            // 
            this.accountSettingsToolStripMenuItem.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accountSettingsToolStripMenuItem.Name = "accountSettingsToolStripMenuItem";
            this.accountSettingsToolStripMenuItem.Size = new System.Drawing.Size(261, 34);
            this.accountSettingsToolStripMenuItem.Text = "Account Settings";
            this.accountSettingsToolStripMenuItem.Click += new System.EventHandler(this.accountSettingsToolStripMenuItem_Click_1);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(261, 34);
            this.logoutToolStripMenuItem.Text = "Log-out";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // lbl_adminname
            // 
            this.lbl_adminname.AutoSize = true;
            this.lbl_adminname.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_adminname.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_adminname.Location = new System.Drawing.Point(868, 6);
            this.lbl_adminname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_adminname.Name = "lbl_adminname";
            this.lbl_adminname.Size = new System.Drawing.Size(73, 29);
            this.lbl_adminname.TabIndex = 34;
            this.lbl_adminname.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(747, 6);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 29);
            this.label3.TabIndex = 33;
            this.label3.Text = "Welcome ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Gabriola", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(11, 43);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(518, 124);
            this.label6.TabIndex = 58;
            this.label6.Text = "Manage User Account";
            // 
            // dtgrid_useracc
            // 
            this.dtgrid_useracc.AllowUserToAddRows = false;
            this.dtgrid_useracc.AllowUserToDeleteRows = false;
            this.dtgrid_useracc.AllowUserToResizeColumns = false;
            this.dtgrid_useracc.AllowUserToResizeRows = false;
            this.dtgrid_useracc.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dtgrid_useracc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgrid_useracc.Location = new System.Drawing.Point(116, 271);
            this.dtgrid_useracc.Margin = new System.Windows.Forms.Padding(4);
            this.dtgrid_useracc.Name = "dtgrid_useracc";
            this.dtgrid_useracc.ReadOnly = true;
            this.dtgrid_useracc.Size = new System.Drawing.Size(1477, 494);
            this.dtgrid_useracc.TabIndex = 59;
            // 
            // _MANSMS_DATABASEDataSet
            // 
            this._MANSMS_DATABASEDataSet.DataSetName = "_MANSMS_DATABASEDataSet";
            this._MANSMS_DATABASEDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mANSMSDATABASEDataSetBindingSource
            // 
            this.mANSMSDATABASEDataSetBindingSource.DataSource = this._MANSMS_DATABASEDataSet;
            this.mANSMSDATABASEDataSetBindingSource.Position = 0;
            // 
            // grpbx_filter
            // 
            this.grpbx_filter.BackColor = System.Drawing.Color.Transparent;
            this.grpbx_filter.Controls.Add(this.cb_seclvl);
            this.grpbx_filter.Controls.Add(this.label1);
            this.grpbx_filter.Controls.Add(this.cb_gender);
            this.grpbx_filter.Controls.Add(this.lbl_gender);
            this.grpbx_filter.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbx_filter.Location = new System.Drawing.Point(116, 158);
            this.grpbx_filter.Margin = new System.Windows.Forms.Padding(4);
            this.grpbx_filter.Name = "grpbx_filter";
            this.grpbx_filter.Padding = new System.Windows.Forms.Padding(4);
            this.grpbx_filter.Size = new System.Drawing.Size(759, 82);
            this.grpbx_filter.TabIndex = 60;
            this.grpbx_filter.TabStop = false;
            this.grpbx_filter.Text = "Filter By :";
            // 
            // cb_seclvl
            // 
            this.cb_seclvl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.cb_seclvl.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_seclvl.FormattingEnabled = true;
            this.cb_seclvl.Items.AddRange(new object[] {
            "Admin",
            "User"});
            this.cb_seclvl.Location = new System.Drawing.Point(579, 33);
            this.cb_seclvl.Margin = new System.Windows.Forms.Padding(4);
            this.cb_seclvl.Name = "cb_seclvl";
            this.cb_seclvl.Size = new System.Drawing.Size(160, 37);
            this.cb_seclvl.TabIndex = 71;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(389, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 29);
            this.label1.TabIndex = 70;
            this.label1.Text = "Security Level  :";
            // 
            // cb_gender
            // 
            this.cb_gender.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.cb_gender.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_gender.FormattingEnabled = true;
            this.cb_gender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cb_gender.Location = new System.Drawing.Point(192, 33);
            this.cb_gender.Margin = new System.Windows.Forms.Padding(4);
            this.cb_gender.Name = "cb_gender";
            this.cb_gender.Size = new System.Drawing.Size(160, 37);
            this.cb_gender.TabIndex = 69;
            // 
            // lbl_gender
            // 
            this.lbl_gender.AutoSize = true;
            this.lbl_gender.BackColor = System.Drawing.Color.Transparent;
            this.lbl_gender.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gender.Location = new System.Drawing.Point(72, 39);
            this.lbl_gender.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_gender.Name = "lbl_gender";
            this.lbl_gender.Size = new System.Drawing.Size(103, 29);
            this.lbl_gender.TabIndex = 68;
            this.lbl_gender.Text = "Gender  :";
            // 
            // grpbx_search
            // 
            this.grpbx_search.BackColor = System.Drawing.Color.Transparent;
            this.grpbx_search.Controls.Add(this.txt_fname);
            this.grpbx_search.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbx_search.Location = new System.Drawing.Point(895, 158);
            this.grpbx_search.Margin = new System.Windows.Forms.Padding(4);
            this.grpbx_search.Name = "grpbx_search";
            this.grpbx_search.Padding = new System.Windows.Forms.Padding(4);
            this.grpbx_search.Size = new System.Drawing.Size(699, 82);
            this.grpbx_search.TabIndex = 61;
            this.grpbx_search.TabStop = false;
            this.grpbx_search.Text = "Search here :";
            // 
            // txt_fname
            // 
            this.txt_fname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_fname.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fname.Location = new System.Drawing.Point(11, 32);
            this.txt_fname.Margin = new System.Windows.Forms.Padding(4);
            this.txt_fname.Name = "txt_fname";
            this.txt_fname.Size = new System.Drawing.Size(608, 36);
            this.txt_fname.TabIndex = 60;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button3.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(1385, 790);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(165, 43);
            this.button3.TabIndex = 88;
            this.button3.Text = "Cancel";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button2.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(1225, 790);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(132, 43);
            this.button2.TabIndex = 87;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1075, 790);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 43);
            this.button1.TabIndex = 86;
            this.button1.Text = "Edit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frm_useracc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MANSMS_1_.Properties.Resources.PicsArt_10_10_10_02_07___Copy;
            this.ClientSize = new System.Drawing.Size(1394, 961);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.grpbx_search);
            this.Controls.Add(this.grpbx_filter);
            this.Controls.Add(this.dtgrid_useracc);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbl_adminname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_useracc";
            this.Text = "User Account";
            this.Load += new System.EventHandler(this.frm_useracc_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrid_useracc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._MANSMS_DATABASEDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mANSMSDATABASEDataSetBindingSource)).EndInit();
            this.grpbx_filter.ResumeLayout(false);
            this.grpbx_filter.PerformLayout();
            this.grpbx_search.ResumeLayout(false);
            this.grpbx_search.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminProfileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem manageUsersAccountsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scheduleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentsprofileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewStudentsProfileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activityLogToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Label lbl_adminname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dtgrid_useracc;
        private _MANSMS_DATABASEDataSet _MANSMS_DATABASEDataSet;
        private System.Windows.Forms.BindingSource mANSMSDATABASEDataSetBindingSource;
        private System.Windows.Forms.GroupBox grpbx_filter;
        private System.Windows.Forms.ComboBox cb_seclvl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_gender;
        private System.Windows.Forms.Label lbl_gender;
        private System.Windows.Forms.GroupBox grpbx_search;
        private System.Windows.Forms.TextBox txt_fname;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}