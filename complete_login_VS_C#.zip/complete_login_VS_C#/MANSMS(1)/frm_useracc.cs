﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MANSMS_1_
{
    public partial class frm_useracc : Form
    {
        static string conString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\HP\Documents\Visual Studio 2012\Projects\nooo\MANSMS(1)\bin\Debug;";
        private OleDbConnection con = new OleDbConnection(conString);
        //OleDbCommand cmd;
        //OleDbDataAdapter adapter;
        DataTable dt = new DataTable();


        public frm_useracc()
        {
            InitializeComponent();


            dtgrid_useracc.ColumnCount = 9;
            dtgrid_useracc.Columns[0].Name = "ID";
            dtgrid_useracc.Columns[1].Name = "username";
            dtgrid_useracc.Columns[2].Name = "password";
            dtgrid_useracc.Columns[3].Name = "First Name";
            dtgrid_useracc.Columns[4].Name = "Middle Name";
            dtgrid_useracc.Columns[5].Name = "Last Name";
            dtgrid_useracc.Columns[6].Name = "Security Level";
            dtgrid_useracc.Columns[7].Name = "Contact No.";
            dtgrid_useracc.Columns[8].Name = "Gender";


            dtgrid_useracc.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dtgrid_useracc.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtgrid_useracc.MultiSelect = false;

        }

        private void frm_useracc_Load(object sender, EventArgs e)
        {
            
        }

        private void adminProfileToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_adminprofile vfrmadminprofile = new frm_adminprofile();
            vfrmadminprofile.Show();
        }

        private void loginHistoryToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_userloginhis vfrmuserloginhis = new frm_userloginhis();
            vfrmuserloginhis.Show();
        }

        private void scheduleToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_usersched vfrmusersched = new frm_usersched();
            vfrmusersched.Show();
        }

        private void studentsprofileToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_stdprof vfrmstdprof = new frm_stdprof();
            vfrmstdprof.Show();
        }

        private void addNewStudentsProfileToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_addstdprof vfrmaddstdprof = new frm_addstdprof();
            vfrmaddstdprof.Show();
        }

        private void activityLogToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_stdactlog vfrmstdacclog = new frm_stdactlog();
            vfrmstdacclog.Show();
        }

        private void accountSettingsToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_accsett vfrmaccsett = new frm_accsett();
            vfrmaccsett.Show();
        }

        private void menuToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dtgrid_useracc.AllowUserToAddRows = true;
            dtgrid_useracc.AllowUserToDeleteRows = true;

            button1.Visible = false;
            button2.Visible = true;
            button3.Visible = true;


        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.Visible = true;
            button2.Visible = false;
            button3.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button1.Visible = true;
            button2.Visible = false;
            button3.Visible = false;

        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder qry = new StringBuilder();
            qry.AppendLine("INSERT INTO UserLogs ");
            qry.AppendLine("(");
            qry.AppendLine("UserId,");
            qry.AppendLine("Activity,");
            qry.AppendLine("LogDate,");
            qry.AppendLine("Remarks");
            qry.AppendLine(") VALUES (");
            qry.AppendLine("'" + GlobalVariable.LoggedInUser.Rows[0].Field<int>("ID").ToString() + "',");
            qry.AppendLine("'" + Enums.Activity.LOGOUT.ToString() + "',");
            qry.AppendLine("'" + DateTime.Now.ToString("MMM-dd-yyyy hh:mm:ss tt") + "',");
            qry.AppendLine("'" + "" + "'");
            qry.AppendLine(")");
            DataAccessLayer.ExecuteNonQuery(qry.ToString());

            this.Close();

            Program.FRM_LOGIN.Show();
        }
    }
}
