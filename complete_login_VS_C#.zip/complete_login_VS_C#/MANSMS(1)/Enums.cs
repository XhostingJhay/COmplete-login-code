﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MANSMS_1_
{
   public static class Enums
    {
        public enum Activity
        {
            LOGIN,
            LOGOUT,
            CREATED,
            MODIFIED,
            DELETED
        }
    }
}
