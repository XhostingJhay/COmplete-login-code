﻿namespace MANSMS_1_
{
    partial class frm_accsett
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminProfileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.manageUsersAccountsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewUsersAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentsprofileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewStudentsProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activityLogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbl_adminname = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.grpbx_filter = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_conpassword = new System.Windows.Forms.TextBox();
            this.txt_retypeusername = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_newusername = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_username = new System.Windows.Forms.TextBox();
            this.lbl_contactno = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txt_confpassword = new System.Windows.Forms.TextBox();
            this.txt_retypepassword = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_newpassword = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.grpbx_filter.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminToolStripMenuItem,
            this.menuToolStripMenuItem,
            this.settingsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1394, 37);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.adminToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminProfileToolStripMenuItem1,
            this.manageUsersAccountsToolStripMenuItem});
            this.adminToolStripMenuItem.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(169, 33);
            this.adminToolStripMenuItem.Text = "Administrator";
            // 
            // adminProfileToolStripMenuItem1
            // 
            this.adminProfileToolStripMenuItem1.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminProfileToolStripMenuItem1.Name = "adminProfileToolStripMenuItem1";
            this.adminProfileToolStripMenuItem1.Size = new System.Drawing.Size(337, 34);
            this.adminProfileToolStripMenuItem1.Text = "Profile";
            this.adminProfileToolStripMenuItem1.Click += new System.EventHandler(this.adminProfileToolStripMenuItem1_Click);
            // 
            // manageUsersAccountsToolStripMenuItem
            // 
            this.manageUsersAccountsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewUsersAccountToolStripMenuItem,
            this.loginHistoryToolStripMenuItem,
            this.scheduleToolStripMenuItem});
            this.manageUsersAccountsToolStripMenuItem.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manageUsersAccountsToolStripMenuItem.Name = "manageUsersAccountsToolStripMenuItem";
            this.manageUsersAccountsToolStripMenuItem.Size = new System.Drawing.Size(337, 34);
            this.manageUsersAccountsToolStripMenuItem.Text = "Manage User\'s Accounts";
            this.manageUsersAccountsToolStripMenuItem.Click += new System.EventHandler(this.manageUsersAccountsToolStripMenuItem_Click);
            // 
            // viewUsersAccountToolStripMenuItem
            // 
            this.viewUsersAccountToolStripMenuItem.Name = "viewUsersAccountToolStripMenuItem";
            this.viewUsersAccountToolStripMenuItem.Size = new System.Drawing.Size(295, 34);
            this.viewUsersAccountToolStripMenuItem.Text = "View User\'s Account";
            this.viewUsersAccountToolStripMenuItem.Click += new System.EventHandler(this.viewUsersAccountToolStripMenuItem_Click);
            // 
            // loginHistoryToolStripMenuItem
            // 
            this.loginHistoryToolStripMenuItem.Name = "loginHistoryToolStripMenuItem";
            this.loginHistoryToolStripMenuItem.Size = new System.Drawing.Size(295, 34);
            this.loginHistoryToolStripMenuItem.Text = "Log-in History";
            this.loginHistoryToolStripMenuItem.Click += new System.EventHandler(this.loginHistoryToolStripMenuItem_Click);
            // 
            // scheduleToolStripMenuItem
            // 
            this.scheduleToolStripMenuItem.Name = "scheduleToolStripMenuItem";
            this.scheduleToolStripMenuItem.Size = new System.Drawing.Size(295, 34);
            this.scheduleToolStripMenuItem.Text = "Schedule";
            this.scheduleToolStripMenuItem.Click += new System.EventHandler(this.scheduleToolStripMenuItem_Click);
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentsprofileToolStripMenuItem,
            this.activityLogToolStripMenuItem});
            this.menuToolStripMenuItem.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(273, 33);
            this.menuToolStripMenuItem.Text = "Manage User\'s Students";
            // 
            // studentsprofileToolStripMenuItem
            // 
            this.studentsprofileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewStudentsProfileToolStripMenuItem});
            this.studentsprofileToolStripMenuItem.Name = "studentsprofileToolStripMenuItem";
            this.studentsprofileToolStripMenuItem.Size = new System.Drawing.Size(209, 34);
            this.studentsprofileToolStripMenuItem.Text = "Profile";
            this.studentsprofileToolStripMenuItem.Click += new System.EventHandler(this.studentsprofileToolStripMenuItem_Click);
            // 
            // addNewStudentsProfileToolStripMenuItem
            // 
            this.addNewStudentsProfileToolStripMenuItem.Name = "addNewStudentsProfileToolStripMenuItem";
            this.addNewStudentsProfileToolStripMenuItem.Size = new System.Drawing.Size(354, 34);
            this.addNewStudentsProfileToolStripMenuItem.Text = "Add New Student\'s Profile";
            this.addNewStudentsProfileToolStripMenuItem.Click += new System.EventHandler(this.addNewStudentsProfileToolStripMenuItem_Click);
            // 
            // activityLogToolStripMenuItem
            // 
            this.activityLogToolStripMenuItem.Name = "activityLogToolStripMenuItem";
            this.activityLogToolStripMenuItem.Size = new System.Drawing.Size(209, 34);
            this.activityLogToolStripMenuItem.Text = "Activity Log";
            this.activityLogToolStripMenuItem.Click += new System.EventHandler(this.activityLogToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoutToolStripMenuItem});
            this.settingsToolStripMenuItem.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(110, 33);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(165, 34);
            this.logoutToolStripMenuItem.Text = "Log-out";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // lbl_adminname
            // 
            this.lbl_adminname.AutoSize = true;
            this.lbl_adminname.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_adminname.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_adminname.Location = new System.Drawing.Point(868, 6);
            this.lbl_adminname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_adminname.Name = "lbl_adminname";
            this.lbl_adminname.Size = new System.Drawing.Size(73, 29);
            this.lbl_adminname.TabIndex = 34;
            this.lbl_adminname.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(753, 6);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 29);
            this.label3.TabIndex = 33;
            this.label3.Text = "Welcome ";
            // 
            // grpbx_filter
            // 
            this.grpbx_filter.BackColor = System.Drawing.Color.Transparent;
            this.grpbx_filter.Controls.Add(this.groupBox1);
            this.grpbx_filter.Controls.Add(this.txt_retypeusername);
            this.grpbx_filter.Controls.Add(this.label2);
            this.grpbx_filter.Controls.Add(this.txt_newusername);
            this.grpbx_filter.Controls.Add(this.label1);
            this.grpbx_filter.Controls.Add(this.txt_username);
            this.grpbx_filter.Controls.Add(this.lbl_contactno);
            this.grpbx_filter.Controls.Add(this.button3);
            this.grpbx_filter.Controls.Add(this.button2);
            this.grpbx_filter.Controls.Add(this.button1);
            this.grpbx_filter.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbx_filter.Location = new System.Drawing.Point(127, 260);
            this.grpbx_filter.Margin = new System.Windows.Forms.Padding(4);
            this.grpbx_filter.Name = "grpbx_filter";
            this.grpbx_filter.Padding = new System.Windows.Forms.Padding(4);
            this.grpbx_filter.Size = new System.Drawing.Size(679, 508);
            this.grpbx_filter.TabIndex = 97;
            this.grpbx_filter.TabStop = false;
            this.grpbx_filter.Text = "Username Settings";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.txt_conpassword);
            this.groupBox1.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(29, 305);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(613, 106);
            this.groupBox1.TabIndex = 111;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Please Type Your Password for Confirmation";
            // 
            // txt_conpassword
            // 
            this.txt_conpassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_conpassword.Enabled = false;
            this.txt_conpassword.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_conpassword.Location = new System.Drawing.Point(24, 43);
            this.txt_conpassword.Margin = new System.Windows.Forms.Padding(4);
            this.txt_conpassword.Name = "txt_conpassword";
            this.txt_conpassword.PasswordChar = '*';
            this.txt_conpassword.Size = new System.Drawing.Size(565, 36);
            this.txt_conpassword.TabIndex = 111;
            // 
            // txt_retypeusername
            // 
            this.txt_retypeusername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_retypeusername.Enabled = false;
            this.txt_retypeusername.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_retypeusername.Location = new System.Drawing.Point(273, 234);
            this.txt_retypeusername.Margin = new System.Windows.Forms.Padding(4);
            this.txt_retypeusername.Name = "txt_retypeusername";
            this.txt_retypeusername.Size = new System.Drawing.Size(347, 36);
            this.txt_retypeusername.TabIndex = 110;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 238);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(216, 29);
            this.label2.TabIndex = 109;
            this.label2.Text = "Re-type Username  :";
            // 
            // txt_newusername
            // 
            this.txt_newusername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_newusername.Enabled = false;
            this.txt_newusername.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_newusername.Location = new System.Drawing.Point(273, 150);
            this.txt_newusername.Margin = new System.Windows.Forms.Padding(4);
            this.txt_newusername.Name = "txt_newusername";
            this.txt_newusername.Size = new System.Drawing.Size(347, 36);
            this.txt_newusername.TabIndex = 108;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 154);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 29);
            this.label1.TabIndex = 107;
            this.label1.Text = "New Username  :";
            // 
            // txt_username
            // 
            this.txt_username.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_username.Enabled = false;
            this.txt_username.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_username.Location = new System.Drawing.Point(273, 69);
            this.txt_username.Margin = new System.Windows.Forms.Padding(4);
            this.txt_username.Name = "txt_username";
            this.txt_username.Size = new System.Drawing.Size(347, 36);
            this.txt_username.TabIndex = 106;
            // 
            // lbl_contactno
            // 
            this.lbl_contactno.AutoSize = true;
            this.lbl_contactno.BackColor = System.Drawing.Color.Transparent;
            this.lbl_contactno.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_contactno.Location = new System.Drawing.Point(37, 73);
            this.lbl_contactno.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_contactno.Name = "lbl_contactno";
            this.lbl_contactno.Size = new System.Drawing.Size(133, 29);
            this.lbl_contactno.TabIndex = 105;
            this.lbl_contactno.Text = "Username  :";
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button3.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(408, 441);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(165, 43);
            this.button3.TabIndex = 104;
            this.button3.Text = "Cancel";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button2.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(248, 441);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(132, 43);
            this.button2.TabIndex = 103;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(97, 441);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 43);
            this.button1.TabIndex = 102;
            this.button1.Text = "Edit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Gabriola", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(0, 38);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(404, 124);
            this.label6.TabIndex = 96;
            this.label6.Text = "Account Settings";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.txt_retypepassword);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txt_newpassword);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txt_password);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(915, 260);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(679, 508);
            this.groupBox2.TabIndex = 98;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Password Settings";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.txt_confpassword);
            this.groupBox3.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(29, 305);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(613, 106);
            this.groupBox3.TabIndex = 111;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Please Type Your Password for Confirmation";
            // 
            // txt_confpassword
            // 
            this.txt_confpassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_confpassword.Enabled = false;
            this.txt_confpassword.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_confpassword.Location = new System.Drawing.Point(24, 43);
            this.txt_confpassword.Margin = new System.Windows.Forms.Padding(4);
            this.txt_confpassword.Name = "txt_confpassword";
            this.txt_confpassword.PasswordChar = '*';
            this.txt_confpassword.Size = new System.Drawing.Size(565, 36);
            this.txt_confpassword.TabIndex = 111;
            // 
            // txt_retypepassword
            // 
            this.txt_retypepassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_retypepassword.Enabled = false;
            this.txt_retypepassword.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_retypepassword.Location = new System.Drawing.Point(273, 234);
            this.txt_retypepassword.Margin = new System.Windows.Forms.Padding(4);
            this.txt_retypepassword.Name = "txt_retypepassword";
            this.txt_retypepassword.PasswordChar = '*';
            this.txt_retypepassword.Size = new System.Drawing.Size(347, 36);
            this.txt_retypepassword.TabIndex = 110;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(37, 238);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(211, 29);
            this.label4.TabIndex = 109;
            this.label4.Text = "Re-type Password  :";
            // 
            // txt_newpassword
            // 
            this.txt_newpassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_newpassword.Enabled = false;
            this.txt_newpassword.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_newpassword.Location = new System.Drawing.Point(273, 150);
            this.txt_newpassword.Margin = new System.Windows.Forms.Padding(4);
            this.txt_newpassword.Name = "txt_newpassword";
            this.txt_newpassword.PasswordChar = '*';
            this.txt_newpassword.Size = new System.Drawing.Size(347, 36);
            this.txt_newpassword.TabIndex = 108;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(37, 154);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(180, 29);
            this.label5.TabIndex = 107;
            this.label5.Text = "New Password  :";
            // 
            // txt_password
            // 
            this.txt_password.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_password.Enabled = false;
            this.txt_password.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_password.Location = new System.Drawing.Point(273, 69);
            this.txt_password.Margin = new System.Windows.Forms.Padding(4);
            this.txt_password.Name = "txt_password";
            this.txt_password.PasswordChar = '*';
            this.txt_password.Size = new System.Drawing.Size(347, 36);
            this.txt_password.TabIndex = 106;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(37, 73);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 29);
            this.label7.TabIndex = 105;
            this.label7.Text = "Password  :";
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button4.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(408, 441);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(165, 43);
            this.button4.TabIndex = 104;
            this.button4.Text = "Cancel";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button5.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(248, 441);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(132, 43);
            this.button5.TabIndex = 103;
            this.button5.Text = "Save";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Visible = false;
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button6.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(97, 441);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(123, 43);
            this.button6.TabIndex = 102;
            this.button6.Text = "Edit";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // frm_accsett
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MANSMS_1_.Properties.Resources.PicsArt_10_10_10_02_07___Copy;
            this.ClientSize = new System.Drawing.Size(1394, 961);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.grpbx_filter);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbl_adminname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_accsett";
            this.Text = "Account Settings";
            this.Load += new System.EventHandler(this.frm_accsett_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpbx_filter.ResumeLayout(false);
            this.grpbx_filter.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminProfileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem manageUsersAccountsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewUsersAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scheduleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentsprofileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewStudentsProfileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activityLogToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Label lbl_adminname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox grpbx_filter;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txt_retypeusername;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_newusername;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_username;
        private System.Windows.Forms.Label lbl_contactno;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_conpassword;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txt_confpassword;
        private System.Windows.Forms.TextBox txt_retypepassword;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_newpassword;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
    }
}