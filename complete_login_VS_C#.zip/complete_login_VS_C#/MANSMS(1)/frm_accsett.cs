﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MANSMS_1_
{
    public partial class frm_accsett : Form
    {
        public frm_accsett()
        {
            InitializeComponent();
        }

        private void adminProfileToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_adminprofile vfrmadminprofile = new frm_adminprofile();
            vfrmadminprofile.Show();
        }

        private void manageUsersAccountsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void viewUsersAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_useracc vfrmuseracc = new frm_useracc();
            vfrmuseracc.Show();
        }

        private void loginHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_userloginhis vfrmuserloginhis = new frm_userloginhis();
            vfrmuserloginhis.Show();
        }

        private void scheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_usersched vfrmusersched = new frm_usersched();
            vfrmusersched.Show();
        }

        private void addNewStudentsProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_addstdprof vfrmaddstdprof = new frm_addstdprof();
            vfrmaddstdprof.Show();
        }

        private void studentsprofileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_stdprof vfrmstdprof = new frm_stdprof();
            vfrmstdprof.Show();
        }

        private void activityLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_stdactlog vfrmstdacclog = new frm_stdactlog();
            vfrmstdacclog.Show();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder qry = new StringBuilder();
            qry.AppendLine("INSERT INTO UserLogs ");
            qry.AppendLine("(");
            qry.AppendLine("UserId,");
            qry.AppendLine("Activity,");
            qry.AppendLine("LogDate,");
            qry.AppendLine("Remarks");
            qry.AppendLine(") VALUES (");
            qry.AppendLine("'" + GlobalVariable.LoggedInUser.Rows[0].Field<int>("ID").ToString() + "',");
            qry.AppendLine("'" + Enums.Activity.LOGOUT.ToString() + "',");
            qry.AppendLine("'" + DateTime.Now.ToString("MMM-dd-yyyy hh:mm:ss tt") + "',");
            qry.AppendLine("'" + "" + "'");
            qry.AppendLine(")");
            DataAccessLayer.ExecuteNonQuery(qry.ToString());

            this.Close();

            Program.FRM_LOGIN.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txt_username.Enabled = true;
            txt_newusername.Enabled = true;
            txt_conpassword.Enabled = true;
            txt_retypeusername.Enabled = true;

            button1.Visible = false;
            button2.Visible = true;
            button3.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            txt_confpassword.Enabled = true;
            txt_newpassword.Enabled = true;
            txt_password.Enabled = true;
            txt_retypepassword.Enabled = true;
            
            button6.Visible = false;
            button5.Visible = true;
            button4.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txt_username.Enabled = false;
            txt_newusername.Enabled = false;
            txt_conpassword.Enabled = false;
            txt_retypeusername.Enabled = false;
            
            button1.Visible = true;
            button2.Visible = false;
            button3.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txt_confpassword.Enabled = false;
            txt_newpassword.Enabled = false;
            txt_password.Enabled = false;
            txt_retypepassword.Enabled = false;
            
            button6.Visible = true;
            button5.Visible = false;
            button4.Visible = false;
        }

        private void frm_accsett_Load(object sender, EventArgs e)
        {
            var loggedInUser = GlobalVariable.LoggedInUser;
            lbl_adminname.Text = loggedInUser.Rows[0].Field<string>("username");

            txt_username.Text = loggedInUser.Rows[0].Field<string>("username");
            txt_password.Text = loggedInUser.Rows[0].Field<string>("password");
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var usernamesett = DataAccessLayer.GetRecords("Update UserAccount set username='" + txt_retypeusername.Text + "'; ");

            try
            {
                if (txt_password.Text == String.Empty || txt_username.Text == String.Empty)
                {
                    MessageBox.Show("Please Enter Data!", "Message");
                }
                else
                {
                    var loginResult = DataAccessLayer.GetRecords("SELECT * FROM UserAccount where [username]= '" + txt_retypeusername.Text + "'");

                    if (loginResult.Rows.Count == 0)
                    {
                        MessageBox.Show("Password Incorrect!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return;
                    }
                    else
                    {
                        MessageBox.Show("Record Saved !", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);


                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed due to " + ex.Message, "Message");
            }


        }
    }
}
