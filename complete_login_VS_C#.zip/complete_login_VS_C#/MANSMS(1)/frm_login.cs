﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MANSMS_1_
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void btn_signup_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_signup vfrmsignup = new frm_signup();
            vfrmsignup.ShowDialog();
            this.Show();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_password.Text == String.Empty || txt_username.Text == String.Empty)
                {
                    MessageBox.Show("Please Enter Data!", "Message");
                }
                else
                {
                    var loginResult = DataAccessLayer.GetRecords("SELECT * FROM UserAccount where username= '" + txt_username.Text + "'and [password]='" + txt_password.Text + "'");

                    if (loginResult.Rows.Count == 0)
                    {
                        MessageBox.Show("Invalid Credentials!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return;
                    }
                    else
                    {
                        GlobalVariable.LoggedInUser = loginResult;

                        
                        StringBuilder qry = new StringBuilder();
                        qry.AppendLine("INSERT INTO UserLogs ");
                        qry.AppendLine("(");
                        qry.AppendLine("UserId,");
                        qry.AppendLine("Activity,");
                        qry.AppendLine("LogDate");
                        qry.AppendLine(") VALUES (");
                        qry.AppendLine("'" + loginResult.Rows[0].Field<int>("ID").ToString() + "',");
                        qry.AppendLine("'" + Enums.Activity.LOGIN.ToString() + "',");
                        qry.AppendLine("'" + DateTime.Now.ToString("MMM-dd-yyyy hh:mm:ss tt")+ "'");
                        qry.AppendLine(")");
                        DataAccessLayer.ExecuteNonQuery(qry.ToString());


                        MessageBox.Show("Log-in Successful!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        frm_loading vfrmloading = new frm_loading();
                        vfrmloading.Show();
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed due to " + ex.Message, "Message");
            }


        }

        private void frm_login_Load(object sender, EventArgs e)
        {

        }

        private void txt_password_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
