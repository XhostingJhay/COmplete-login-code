﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MANSMS_1_
{
    public partial class frm_adminprofile : Form
    {
        public frm_adminprofile()
        {
            InitializeComponent();
        }

        private void viewUsersAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_useracc vfrmuseracc = new frm_useracc();
            vfrmuseracc.Show();
        }

        private void loginHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_userloginhis vfrmuserloginhis = new frm_userloginhis();
            vfrmuserloginhis.Show();
        }
       
        private void accountSettingsToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_accsett vfrmaccsett = new frm_accsett();
            vfrmaccsett.Show();
        }

        private void scheduleToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_usersched vfrmusersched = new frm_usersched();
            vfrmusersched.Show();
        }

        private void studentsprofileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_stdprof vfrmstdprof = new frm_stdprof();
            vfrmstdprof.Show();
        }

        private void addNewStudentsProfileToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_addstdprof vfrmaddstdprof = new frm_addstdprof();
            vfrmaddstdprof.Show();
        }

        private void activityLogToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm_stdactlog vfrmstdacclog = new frm_stdactlog();
            vfrmstdacclog.Show();
        }

        private void frm_adminprofile_Load(object sender, EventArgs e)
        {
            
            var loggedInUser = GlobalVariable.LoggedInUser;
            lbl_adminname.Text = loggedInUser.Rows[0].Field<string>("username");
            
            txt_lname.Text = loggedInUser.Rows[0].Field<string>("lname");
            txt_fname.Text = loggedInUser.Rows[0].Field<string>("fname");
            txt_mi.Text = loggedInUser.Rows[0].Field<string>("mi");
            txt_contactno.Text = loggedInUser.Rows[0].Field<string>("contact");
            cb_gender.Text = loggedInUser.Rows[0].Field<string>("gender");
            

          
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var adminprofile = DataAccessLayer.GetRecords("Update UserAccount set lname='" + txt_lname.Text + "',fname='" + txt_fname.Text + "',mi='" + txt_mi.Text + "',contact= '" + txt_contactno.Text + "',gender='" + cb_gender.Text + "'; ");
            MessageBox.Show("Record Saved !", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txt_fname.Enabled = false;
            txt_lname.Enabled = false;
            txt_mi.Enabled = false;
            txt_contactno.Enabled = false;
            cb_gender.Enabled = false;           
            button5.Visible = false;
            button4.Visible = false;
            button6.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button5.Enabled = true;
            txt_fname.Enabled = true;
            txt_lname.Enabled = true;
            txt_mi.Enabled = true;
            txt_contactno.Enabled = true;
            cb_gender.Enabled = true;
            button6.Visible = false;
            button4.Visible = true;
            button5.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button5.Visible = false;
            button4.Visible = false;
            button6.Visible = true;
            
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder qry = new StringBuilder();
            qry.AppendLine("INSERT INTO UserLogs ");
            qry.AppendLine("(");
            qry.AppendLine("UserId,");
            qry.AppendLine("Activity,");
            qry.AppendLine("LogDate,");
            qry.AppendLine("Remarks");
            qry.AppendLine(") VALUES (");
            qry.AppendLine("'" + GlobalVariable.LoggedInUser.Rows[0].Field<int>("ID").ToString() + "',");
            qry.AppendLine("'" + Enums.Activity.LOGOUT.ToString() + "',");
            qry.AppendLine("'" + DateTime.Now.ToString("MMM-dd-yyyy hh:mm:ss tt") + "',");
            qry.AppendLine("'" + "" + "'");
            qry.AppendLine(")");
            DataAccessLayer.ExecuteNonQuery(qry.ToString());

            this.Close();

            Program.FRM_LOGIN.Show();
        }

        
    }
}
